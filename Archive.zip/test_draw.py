from turtle import *


fd(100)
up()
fd(100) 
down()
