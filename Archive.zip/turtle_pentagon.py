from turtle import *

def draw_pentagon():
    left(54)
    fd(120)
    for i in range(4):
        right(72)
        fd(120)
        


fillcolor("blue")

begin_fill()
draw_pentagon()
end_fill()

mainloop()
