from shapes import *


draw_triangle()
up()
fd(100)
down()

draw_square()
up()
fd(100)
down()

draw_pentagon()
up()
fd(100)
down()

draw_hexagon()
up()
fd(100)
down()

draw_octagon()
up()
fd(100)
down()

draw_star()
up()
fd(100)
down()

draw_circle()
up()
fd(100)
down()


mainloop()
