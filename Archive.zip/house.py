from shapes import *

draw_triangle(120, True, "yellow")
draw_square(120, True, "green")
draw_square(50, True, "black")
draw_circle(5, True, "white")

main_loop()
